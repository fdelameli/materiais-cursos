import javax.swing.JOptionPane;


public class Converte {

	public static void main(String[] args) {

		//int bin[]= new int[8];
		//leBinario(bin);		
		//int dec = converteBinario(bin);
		
		int dec = converteBinario(JOptionPane.showInputDialog("Digite o valor bin�rio a ser convertido:"));
		
		JOptionPane.showMessageDialog(null, "Valor Decimal: " + dec);

	}
	
	static void leBinario(int []bin){
		String msg = "";
		for(int i = 0; i < 8; i++){
			bin[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite o " + (i + 1) + "� n�mero de 8"));
			msg += bin[i];			
		}
		JOptionPane.showMessageDialog(null, "Bin�rio Digitado: " + msg);
	}
	
	static int converteBinario(int []bin){
		
		Recursivo rec = new Recursivo();
		int dec = 0;
		int n = 7;
		for(int i = 0; i < 8; i++){
			dec += rec.eleva(n) * bin[i];
			n--;
		}
		return dec;
		
	}
	
	static int converteBinario(String binario){
		
		int tam = binario.length();
		int bin[]= new int[tam];
		
		for(int i = 0; i < tam; i++){
			bin[i] = Integer.parseInt((binario.charAt(i) + ""));
		}
		
		int dec = 0;
		int n = tam - 1;
		Recursivo rec = new Recursivo();
		for(int i = 0; i < bin.length; i++){
			dec += rec.eleva(n) * bin[i];
			n--;
		}
		return dec;
	}

}
