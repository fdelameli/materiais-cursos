
public class Recursivo {

	int fatorial(int n) {
		if (n == 1)
			return 1;
		else
			return n * fatorial(n - 1);
	}

	int eleva(int n) {
		if (n == 0)
			return 1;
		else
			return 2 * eleva(n - 1);
	}
	
}
