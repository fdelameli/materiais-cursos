import java.io.IOException;

import javax.swing.JOptionPane;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;


public class Leitura {

	//verifica se o usuario digita um numero inteiro
	public int leiaInt(String msg){
		int i=0;
		boolean cond=false;
		do{
			cond = false;
			try {
				i= Integer.parseInt(JOptionPane.showInputDialog(msg));
				}catch(NumberFormatException ioe){
					JOptionPane.showMessageDialog(null, "Digite um numero inteiro!");
					cond = true;
				}
		}while(cond == true);
		return i;
	}
	
	//	verifica se o usuario digita um numero inteiro
	public double leiaDouble(String msg){
		double i=0;
		boolean cond=false;
		do{
			cond = false;
			try {
				i= Double.parseDouble(JOptionPane.showInputDialog(msg));
				}catch(NumberFormatException ioe){
					JOptionPane.showMessageDialog(null, "Digite um numero!");
					cond = true;
				}
		}while(cond == true);
		return i;
	}
}
