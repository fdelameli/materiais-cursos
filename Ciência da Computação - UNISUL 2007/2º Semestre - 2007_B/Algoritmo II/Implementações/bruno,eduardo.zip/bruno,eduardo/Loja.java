import javax.swing.JOptionPane;


public class Loja {

	public static void main(String[] args) {
	
		TEstoque estoque= new TEstoque();
		int j=0;
		Leitura l = new Leitura();
		do{
			if(estoque.getQuantidadeProdutos()>0){
				j = l.leiaInt("Digite: \n"+
						"0-Cadastrar \n"+
						"1-Excluir \n"+
						"2-Consultar \n"+
						"3-Aumentar Pre�o Produto \n"+
						"4-Aumentar Pre�o de Todos \n"+
						"5-Vender \n"+
						"6-Comprar \n"+
						"7-Verificar Estoque \n"+
						"8-Listar Abaixo Minimo \n"+
						"9-Listar Produtos \n"+
						"10-Sair \n");
				switch (j) {
					case 0:
						estoque.inserirProduto();
						break;
					case 1:
						estoque.removerProduto(JOptionPane.showInputDialog("Digite o nome do produto que desja excluir: "));
						break;
					case 2:
						estoque.consultarProduto(JOptionPane.showInputDialog("Digite o nome do produto que desja consultar: "));
						break;
					case 3:
						estoque.almentaPreco(l.leiaDouble("Digite a porcentagen do aumento: "), (JOptionPane.showInputDialog("Digite o nome do produto que desja aumentar o pre�o: ")));
						break;
					case 4:
						estoque.almentaPreco(l.leiaDouble("Digite a porcentagen do aumento: "));
						break;
					case 5:
						estoque.Vender(l.leiaInt("Digite a quantidade que deseja vender: "), JOptionPane.showInputDialog("Digite o nome do produto que deseja vender: "));
						break;
					case 6:
						estoque.almentaQuantidade(l.leiaInt("Digite a quantidade que deseja comprar: "), JOptionPane.showInputDialog("Digite o nome do produto que deseja comprar: "));
						break;
					case 7:
						estoque.atenderPedido(l.leiaInt("Digite a quantidade que deseja verificar: "), JOptionPane.showInputDialog("Digite o nome do produto que deseja veificar: "));
						break;
					case 8:
						estoque.listaProdutosMinimoEstoque();
						break;
					case 9:
						estoque.listaProdutos();
						break;
					case 10:
						JOptionPane.showMessageDialog(null, "Obrigado por usar o Cadastro.\n"+
								"!!!aten��o!!!\n"+"Todos seus arquivos ser�o perdidos\n " +
										"porque esse programa n�o usa\n" +
										" banco de dados!");
						break;
					
					default:
						JOptionPane.showMessageDialog(null, "Esse numero n�o existe no menu!\n" +
																"Digite um numero v�lido");
						break;
				}
			}else{
				j = l.leiaInt("Digite: \n"+
						"0-Cadastrar \n"+
						"10-Sair \n");
				switch (j) {
					case 0:
						estoque.inserirProduto();
						break;
					case 10:
						JOptionPane.showMessageDialog(null, "Obrigado por usar o Cadastro.\n"+
								"!!!aten��o!!!\n"+"Todos seus arquivos ser�o perdidos\n " +
										"porque esse programa n�o usa\n" +
										" banco de dados!");
						break;
					default:
						JOptionPane.showMessageDialog(null, "Esse numero n�o existe no menu!\n" +
																"Digite um numero v�lido");
						break;
				}	
			}	
		}while(j!=10);
			
		}
	
	}
