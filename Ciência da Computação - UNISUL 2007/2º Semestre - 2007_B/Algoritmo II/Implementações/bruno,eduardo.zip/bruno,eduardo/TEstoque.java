import java.util.ArrayList;

import javax.swing.JOptionPane;

public class TEstoque {

	private ArrayList<TProduto> produto = new ArrayList();

	private int quantidadeProdutos;
	private Leitura l = new Leitura();

	// construtor padr�o
	public TEstoque() {
		this.quantidadeProdutos = 0;
	}

	// construtor com parametros
	public TEstoque(int quantidadeProdutos) {
		this.quantidadeProdutos = quantidadeProdutos;
	}

	// insere um produto
	public void inserirProduto() {
		int cont = 0;
		String nome = "";
		nome = JOptionPane.showInputDialog("Digite o nome do produto: ");
		for (int i = 0; i < this.produto.size(); i++) {
			if (nome.equals(this.produto.get(i).getNome())) {
				JOptionPane.showMessageDialog(null, "Esse Produto j� existe");
				cont++;
			}
		}
		if (cont == 0) {
			TProduto produto = new TProduto(
					(l.leiaInt("Digite o c�digo: ")),
					nome,
					(l.leiaDouble("Digite o preco: ")),
					(l.leiaInt("Digite a quantidade em Estoque: ")),
					(l.leiaInt("Digite a quantidade minima em Estoque: ")));
			this.produto.add(produto);
			this.quantidadeProdutos++;
		}

	}

	// remove um produto
	public void removerProduto(String nome) {
		int cont = 0;
		for (int i = 0; i < this.produto.size(); i++) {
			if (nome.equals(this.produto.get(i).getNome())) {
					this.produto.remove(i);
					cont++;
					this.quantidadeProdutos--;
			}
		}
			if (cont == 1) {
				JOptionPane.showMessageDialog(null,"Produto Removido com sucesso!");
			} else {
				JOptionPane.showMessageDialog(null, "Esse produto n�o existe!");
				}
	}

	// consulta dados de um produto atraves do nome
	public void consultarProduto(String nome) {
		int cont = 0;
		for (int i = 0; i < this.produto.size(); i++) {
			if (nome.equals(this.produto.get(i).getNome())) {
				JOptionPane.showMessageDialog(null, produto.get(i).toString());
				cont++;
			}
		}
		if (cont == 0) {
			JOptionPane.showMessageDialog(null, "Esse produto n�o existe!");
		}
	} 
	

	// almenta o pre�o de todos os produtos conforme a porcentagem que o usuario passa
	public void almentaPreco(double porcentagem) {
		for (int i = 0; i < this.produto.size(); i++) {
			this.produto.get(i).aumentaPreco(porcentagem);
		}
		JOptionPane.showMessageDialog(null,"Pre�o de todos os produtos aumentado em "+ (porcentagem) + "%");
	}
	
	// almenta o pre�o de um produto conforme a porcentagem que o usuario passa
	public void almentaPreco(double porcentagem, String nome) {
		int cont = 0;
		for (int i = 0; i < this.produto.size(); i++) {
			if (nome.equals(this.produto.get(i).getNome())) {
				this.produto.get(i).aumentaPreco(porcentagem);
				cont++;
				JOptionPane.showMessageDialog(null, "Pre�o do produto "+ (nome) + " aumentado em " + (porcentagem)+ "% !");
			}
		}
		if (cont == 0) {
				JOptionPane.showMessageDialog(null, "Esse produto n�o existe!");
		}
		
	}

	// aumenta a quantidade em estoque de um determinado produto
	public void almentaQuantidade(int quantidade, String nome) {
		int cont = 0;
		for (int i = 0; i < this.produto.size(); i++) {
			if (nome.equals(this.produto.get(i).getNome())) {
				this.produto.get(i).incrementaQuantidade(quantidade);
				cont++;
				JOptionPane.showMessageDialog(null,"A quantidade do produto " + (nome)+ " foi aumentado em " + (quantidade)+ " unidades!");
			}
		}
		if (cont == 0) {
			JOptionPane.showMessageDialog(null, "Esse produto n�o existe!");
		}
		
	}

	// diminui a quantidade em estoque de um determinado produto
	public void diminuiQuantidade(int quantidade, String nome) {
		int cont = 0;
		if (this.produto.size() > 0) {
			for (int i = 0; i < this.produto.size(); i++) {
				if (nome.equals(this.produto.get(i).getNome())) {
					this.produto.get(i).decrementaQuantidade(quantidade);
					cont++;
					JOptionPane.showMessageDialog(null,"A quantidade do produto " + (nome)+ " foi diminuida em " + (quantidade)+ " unidades!");
				}
			}
			if (cont == 0) {
				JOptionPane.showMessageDialog(null,"Esse produto n�o existe!");
			}
		}
		
	}

	// verifica se a quantidade especificada � existente no estoque do produto especifico
	public void atenderPedido(int quantidade, String nome) {
		int cont = 0;
		for (int i = 0; i < this.produto.size(); i++) {
			if (nome.equals(this.produto.get(i).getNome())) {
				cont++;
				if (produto.get(i).getQEstoque() >= quantidade) {
						JOptionPane.showMessageDialog(null,"Quantidade especificada existente em estoque.");
				} else {
					JOptionPane.showMessageDialog(null,"Quantidade especificada n�o existente em estoque.");
				}
			}
		}
		if (cont == 0) {
			JOptionPane.showMessageDialog(null, "Esse produto n�o existe!");
		}
		
	}

	// lista produtos cuja quantidade � inferior a minima de estoque
	public void listaProdutosMinimoEstoque() {
		int cont = 0;
		String resposta = "";
		for (int i = 0; i < this.produto.size(); i++) {
			if (this.produto.get(i).getQEstoque() < this.produto.get(i).getQMinima()) {
				resposta = resposta + this.produto.get(i).getNome() + "\n";
				cont++;
			}
		}
		if (cont == 1) {
			JOptionPane.showMessageDialog(null,"Os produtos com estoque menor que o minimo s�o:\n"+resposta);
		}else{
			JOptionPane.showMessageDialog(null,"N�o ha produtos com quantidade \nmenor que o minimo do estoque");
		}
	} 

	// lista todos os produtos em estoque
	public void listaProdutos() {
		String resposta = "";
		for (int i = 0; i < this.produto.size(); i++) {
			resposta = resposta + this.produto.get(i).toString() + "\n\n";
		}
		JOptionPane.showMessageDialog(null,"Os produtos cadastrados s�o:\n"+resposta);
	}
	
	// vende produto(diminui quantidade em estoque convorme pedido)
	public void Vender(int quantidade, String nome) {
		int cont = 0;
			for (int i = 0; i < this.produto.size(); i++) {
				if (nome.equals(this.produto.get(i).getNome())) {
					cont++;
					if (produto.get(i).getQEstoque() >= quantidade) {
						produto.get(i).decrementaQuantidade(quantidade);
						JOptionPane.showMessageDialog(null,"Venda executado co sucesso!");
						
					} else {
						JOptionPane.showMessageDialog(null,"N�o h� quantidade em estoque do produto "+ (produto.get(i).getNome())+ "\n para atender a demanda do pedido!!");
					}
				}
			}
			if (cont == 0) {
				JOptionPane.showMessageDialog(null, "Esse produto n�o existe!");
			}
	}

	
	public int getQuantidadeProdutos() {
		return quantidadeProdutos;
	}

	
	public void setQuantidadeProdutos(int quantidadeProdutos) {
		this.quantidadeProdutos = quantidadeProdutos;
	} 
	

}
