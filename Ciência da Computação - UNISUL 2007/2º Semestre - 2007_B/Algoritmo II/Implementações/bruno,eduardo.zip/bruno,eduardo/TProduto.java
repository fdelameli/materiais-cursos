
public class TProduto {

	private int codigo;
	private String nome;
	private double preco;
	private int qEstoque;
	private int qMinima;
	
	//construtor padr�o
	public TProduto(){
		
		this.codigo= 0;
		this.nome= "";
		this.preco= 0.0;
		this.qEstoque= 0;
		this.qMinima= 0;
	}
	
	//construtor com parametros
	public TProduto(int codigo, String nome, double preco, int qEstoque, int qMinima){
		
		this.codigo= codigo;
		this.nome= nome;
		this.preco= preco;
		this.qEstoque= qEstoque;
		this.qMinima= qMinima;
	}
	
	//aumenta pre�o atraves de uma porcentagem
	public void aumentaPreco(double porcentagem){
	
		this.preco = ((porcentagem/100)+1)*this.preco;
		
	}
	
	//diminui o pre�o atraves de uma porcentagem
	public void diminuiPreco(double porcentagem){
	
		this.preco = (1-(porcentagem/100))*this.preco;
	}
	
	//incrementa a quantidade em estoque em 1
	public void incrementaQuantidade(){
	
		this.qEstoque++;
	}
	
	//incrementa a quantidade em estoque que o usuario mandar
	public void incrementaQuantidade(int quantidade){
		
		this.qEstoque += quantidade;
	}
	
	//diminui em um a quantidade em estoque
	public void decrementaQuantidade(){
		
			this.qEstoque--;
	}
		
    //diminui a quantidade em estoque conforme o usuario mandar
	public void decrementaQuantidade(int quantidade){
			
			this.qEstoque -= quantidade;
	}
	
	//geter's and seter's
	
	
	public int getCodigo() {
		return codigo;
	}
	
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public double getPreco() {
		return preco;
	}
	
	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	public int getQEstoque() {
		return qEstoque;
	}
	
	public void setQEstoque(int estoque) {
		qEstoque = estoque;
	}
	
	public int getQMinima() {
		return qMinima;
	}

	public void setQMinima(int minima) {
		qMinima = minima;
	}
	
	//retorna todas as variaveis do objeto em formato String 
	public String toString() {
		return ("Nome: "+this.nome+"\n"+
				"C�digo: "+this.codigo+"\n"+
				"Pre�o: "+this.preco+" reais"+"\n"+
				"Quantidade em Estoque: "+this.qEstoque+" unidades"+"\n"+
				"Quantidade Minima: "+this.qMinima+" unidades");
	}
}
