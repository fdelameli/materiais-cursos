import javax.swing.JOptionPane;


public class loja {

	public static void main(String[] args) {
		testoque e= new testoque();
		boolean sair= false;
		
		while (sair==false) {
			int op= Integer.parseInt(JOptionPane.showInputDialog("||||||| MENU |||||||\n\n" +
				"[1]Cadastrar\n[2]Excluir\n[3]Consultar\n" +
				"[4]Aumentar Pre�o Produto\n[5]Aumentar Pre�o de Todos\n" +
				"[6]Vender\n[7]Comprar\n[8]Verificar Estoque\n" +
				"[9]Listar Abaixo M�nimo\n[0]Listar Produtos\n[88]Sair"));
			
			switch (op) {
				case 1: {
					int codigo= Integer.parseInt(JOptionPane.showInputDialog("Codigo:"));
					String nome= JOptionPane.showInputDialog("Nome:");
					if (e.procuraproduto(nome, codigo)== false) {
							tproduto p= new tproduto();
							p.setCodigo(codigo);
							p.setNome(nome);
							p.setPreco(Double.parseDouble(JOptionPane.showInputDialog("Pre�o:")));
							p.setQuantidadeestoque(Integer.parseInt(JOptionPane.showInputDialog("Quantidade de Estoque:")));
							p.setQuantidademinima(Integer.parseInt(JOptionPane.showInputDialog("Quantidade M�nima de Estoque:")));
							e.inserirproduto(p);	
					}else{
						JOptionPane.showMessageDialog(null, "Produto j� Cadastrado !");
					}
					
					break;
				}
				
				case 2: {
					String nome= JOptionPane.showInputDialog("Nome do Produto: ");
					int codigo= 999999999;
					if (e.procuraproduto(nome, codigo)== true) {
						e.removerproduto(nome);
					}else{
						JOptionPane.showMessageDialog(null, "Produto n�o Encontrado !");
					}
					break;
				}
				
				case 3: {
					String nome= JOptionPane.showInputDialog("Nome do Produto: ");
					int codigo= 999999999;
					if (e.procuraproduto(nome, codigo)== true) {
						e.consultarproduto(nome);
					}else{
						JOptionPane.showMessageDialog(null, "Produto n�o Encontrado !");
					}
					break;
				}
				
				case 4: {
					int codigo= 999999999;
					String nome= JOptionPane.showInputDialog("Nome do Produto: ");
					if (e.procuraproduto(nome, codigo)== true){	
						double porcento= Double.parseDouble(JOptionPane.showInputDialog("Porcentagem de Aumento: "));
						e.aumento(nome, porcento);
					}else{
						JOptionPane.showMessageDialog(null, "Produto n�o Encontrado");
					}
					break;
				}
				
				case 5: {
					double porcento= Double.parseDouble(JOptionPane.showInputDialog("Porcentagem de Aumento:"));
					e.aumentogeral(porcento);
					break;
				}
				
				case 6: {
					int codigo= Integer.parseInt(JOptionPane.showInputDialog("Codigo do Produto:"));
					String nome= "9999999999999999999999999";
					if (e.procuraproduto(nome, codigo)== true){	
						int qtd= Integer.parseInt(JOptionPane.showInputDialog("Quantidade a Vender:"));
						if (e.verificandoestoque(codigo, qtd)==true) {
							e.diminuirqtd(codigo, qtd);						
						}else{
							JOptionPane.showMessageDialog(null, "Estoque Indispon�vel !");
						}
					}else{
						JOptionPane.showMessageDialog(null, "Produto n�o Encontrado !");
					}
					break;
				}
				
				case 7: {
					int codigo= Integer.parseInt(JOptionPane.showInputDialog("Codigo do Produto:"));
					String nome= "9999999999999999999999999";
					if (e.procuraproduto(nome, codigo)== true){	
						int qtd= Integer.parseInt(JOptionPane.showInputDialog("Quantidade a Comprar:"));
						e.aumentarqtd(codigo, qtd);						
						break;
					}else{
						JOptionPane.showMessageDialog(null, "Produto n�o Encontrado !");
					}
					break;
				}
				
				case 8: {
					int codigo= Integer.parseInt(JOptionPane.showInputDialog("Codigo do Produto:"));
					String nome= "9999999999999999999999999";
					if (e.procuraproduto(nome, codigo)== true){	
						int qtd= Integer.parseInt(JOptionPane.showInputDialog("Quantidade:"));
						if (e.verificandoestoque(codigo, qtd)==true) {
							JOptionPane.showMessageDialog(null, "Estoque Dispon�vel !");						
						}else{
							JOptionPane.showMessageDialog(null, "Estoque Indispon�vel !");
						}
					}else{
						JOptionPane.showMessageDialog(null, "Produto n�o Encontrado !");
					}
					break;
				}
				
				case 9: {
					JOptionPane.showMessageDialog(null, e.mostraabaixominimo());
					break;
				}
				case 0: {
					JOptionPane.showMessageDialog(null, e.toString());
					break;
				}
				case 88: {
					JOptionPane.showMessageDialog(null, "At� Logo !");
					sair= true;
					break;
				}
				default:{
					JOptionPane.showMessageDialog(null, "Opera��o Inv�lida !");
					break;
				}
			}
		}
	}
}
