import javax.swing.JOptionPane;


public class testoque {
	private tproduto[] produtos;
	private int quantidadeprodutos;
	private tproduto[] novosprodutos;
	
	public testoque(){
		produtos= new tproduto[100];
		quantidadeprodutos= 0;
	}

	public testoque(tproduto[] produtos, int quantidadeprodutos) {
		this.produtos = produtos;
		this.quantidadeprodutos = quantidadeprodutos;
	}
	
	
	public void inserirproduto (tproduto p){
		produtos[quantidadeprodutos]= p;
		quantidadeprodutos ++;
	}

	public void removerproduto (String nome){
		novosprodutos= new tproduto[100];
		int arrumavetor= 0;
		int qtd= quantidadeprodutos;
		for (int i=0; i<quantidadeprodutos; i++){
			if (nome.compareTo(produtos[i].getNome())==0) {
				qtd --;			
			}else{
				novosprodutos[arrumavetor]= produtos[i];
				arrumavetor ++;
			}
		}
		quantidadeprodutos= qtd;
		for (int i=0; i<quantidadeprodutos; i++){
			produtos[i]= novosprodutos[i];
		}
		JOptionPane.showMessageDialog(null, "Produto Exclu�do");
	}
	 
	
	public void consultarproduto (String nome){
		for (int i=0; i<quantidadeprodutos; i++){
			if (nome.compareTo(produtos[i].getNome())==0) {
				JOptionPane.showMessageDialog(null, produtos[i].toString());
			}
		}
	} 
 
	
	public void aumentogeral (double porcento){
		for (int i=0; i<quantidadeprodutos; i++){
			produtos[i].aumentapreco(porcento);
		}
	} 
	
	public void aumento (String nome, double porcento){
		for (int i=0; i<quantidadeprodutos; i++){
			if (nome.compareTo(produtos[i].getNome())==0) {
				produtos[i].aumentapreco(porcento);
			}
		}
	}
	
	
	public void aumentarqtd (int codigo, int qtd){
		for (int i=0; i<quantidadeprodutos; i++){
			if (codigo == produtos[i].getCodigo()){
				produtos[i].incrementaquantidade2(qtd);
			}
		}
	}
	
	public void diminuirqtd (int codigo, int qtd){
		for (int i=0; i<quantidadeprodutos; i++){
			if (codigo == produtos[i].getCodigo()){
				produtos[i].decrementaquantidade2(qtd);
			}
		}
	}
	
	
	public boolean verificandoestoque(int codigo, int qtd) {
		boolean x= true;
		for (int i=0; i<quantidadeprodutos; i++){
			if (codigo==produtos[i].getCodigo()){
				if (qtd > produtos[i].getQuantidadeestoque()){
					x= false;
				}
			}
		}	
		return x;
	}
	
	public boolean procuraproduto(String nome, int codigo){
		boolean x= false;
		for (int i=0; i<quantidadeprodutos; i++){
			if (nome.compareTo(produtos[i].getNome())==0) {
				x= true;
			}
		}
		for (int i=0; i<quantidadeprodutos; i++){
			if (codigo == produtos[i].getCodigo()) {
				x= true;
			}
		}
		return x;
	}
	
	
	public String mostraabaixominimo (){
		int cont= 0;
		String lista= "LISTAGEM DE PRODUTOS \nCOM ESTOQUE ABAIXO DO MINIMO\n\n";
		for (int i=0; i<quantidadeprodutos; i++){
			if (produtos[i].getQuantidadeestoque()<produtos[i].getQuantidademinima()) {
				lista+=produtos[i].toString()+"\n\n";
				cont ++;
			}	
		}
		lista+="Quantidade de Produtos: " + cont;
		return lista;
	}
	
	public String toString(){
		String P="LISTAGEM DE PRODUTOS\n\n";
		for (int i=0; i<quantidadeprodutos; i++){
			P+=produtos[i].toString()+"\n\n";
		}
		P+="Quantidade de Produtos: " + quantidadeprodutos;
		return P;
	}
}
