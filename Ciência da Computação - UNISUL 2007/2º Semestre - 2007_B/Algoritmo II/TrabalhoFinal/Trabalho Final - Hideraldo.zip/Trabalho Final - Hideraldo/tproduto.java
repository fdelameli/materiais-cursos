
public class tproduto {
	private int codigo;
	private String nome;
	private double preco, quantidademinima, quantidadeestoque;
	
	
	
	public tproduto(int codigo, String nome, double preco, double quantidademinima, double quantidadeestoque) {
		this.codigo = codigo;
		this.nome = nome;
		this.preco = preco;
		this.quantidademinima = quantidademinima;
		this.quantidadeestoque = quantidadeestoque;
	}

	public tproduto() {
		this.codigo = 0;
		this.nome = "";
		this.preco = 0.0;
		this.quantidademinima = 0;
		this.quantidadeestoque = 0;
	}	
	
	
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public double getQuantidadeestoque() {
		return quantidadeestoque;
	}

	public void setQuantidadeestoque(double quantidadeestoque) {
		this.quantidadeestoque = quantidadeestoque;
	}

	public double getQuantidademinima() {
		return quantidademinima;
	}

	public void setQuantidademinima(double quantidademinima) {
		this.quantidademinima = quantidademinima;
	}
	
	
	public void aumentapreco(double porcento){
		preco+= preco*porcento/100;
	}
	
	public void diminuipreco(double porcento){
		preco-= preco*porcento/100;
	}
	
	
	public void incrementaquantidade1(){
		quantidadeestoque ++;
	}
	
	public void incrementaquantidade2(int qtd){
		quantidadeestoque += qtd;
	}
	
	public void decrementaquantidade1(){
		quantidadeestoque --;
	}
	public void decrementaquantidade2(int qtd){
		quantidadeestoque -= qtd;
	}
	

	public String toString(){
		return "Codigo: "+ codigo +"\nNome: "+ nome +"\nPre�o: "+ preco + 
		"\nQuantidade de Estoque: " + quantidadeestoque + 
		"\nQuantidade Minima de Estoque: " + quantidademinima;
	}
	
}
