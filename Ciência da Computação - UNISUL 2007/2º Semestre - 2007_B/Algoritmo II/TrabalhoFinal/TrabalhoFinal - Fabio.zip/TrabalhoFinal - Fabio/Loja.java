import javax.swing.JOptionPane;


public class Loja {
	
	static TEstoque estoq = new TEstoque();
	public static void main(String[] args) {

	
	    int op;
	    
	    JOptionPane.showMessageDialog(null, "#SEJAM BEM VINDOS AO NOSSO SISTEMA#");
	    
		do{
			op = Integer.parseInt(
					JOptionPane.showInputDialog("#MENU DO SISTEMA#"
											+"\n\n\n  (1) - Cadastrar um novo Produto" 
											+"\n  (2) - Excluir um Produto"
											+"\n  (3) - Consultar um Produto"
											+"\n  (4) - Aumentar pre�o de todos os Produtos"
											+"\n  (5) - Aumentar pre�o de um Produto Espec�fico"
											+"\n  (6) - Vender um Produto"
											+"\n  (7) - Comprar um Produto"
											+"\n  (8) - Verificar Estoque"
											+"\n  (9) - Listar todos os Produtos com qtd. abaixo do m�nimo"
											+"\n(10) - Listar todos os Produtos" +"\n"
											+"\n  (0) - SAIR"));
		
			switch (op){
			
			case 1:{
				inserirProduto();
				break;
			}
			
			case 2:{
				String msg = "#EXCLUINDO UM PRODUTO#";
				estoq.removerProduto(JOptionPane.showInputDialog(msg + "\n\nPRODUTO A SER EXCLU�DO:"));
				break;
			}
			
			case 3:{
				String msg = "#CONSULTANDO UM PRODUTO#";
				estoq.consultarProduto(JOptionPane.showInputDialog(msg + "\n\nNOME DO PRODUTO:"));
				break;
			}
				
			case (4):{
				String msg = "#AUMENTANDO PRE�O DE TODOS OS PRODUTOS#";
				estoq.aumentoPrecoGeral(Integer.parseInt(JOptionPane.showInputDialog(msg + "\n\nPORCENTAGEM(%) A SER APLICADA:")));
				break;
			}

			case (5):{
				String msg = "#AUMENTANDO PRE�O DE UM PRODUTO#";
				String nome = JOptionPane.showInputDialog(msg + "\n\nNOME DO PRODUTO:");
				
				int pos = estoq.pegaPosicao(nome);
				if (pos<0){
					JOptionPane.showMessageDialog(null,"PRODUTO N�O CADASTRADO!");
				
				}else{
					
					double porcentagem = Double.parseDouble(JOptionPane.showInputDialog(msg + "\n\nPORCENTAGEM(%) A SER APLICADA:"));
					estoq.aumentarPrecoEspecifico(nome, porcentagem);
				}
				break;
			}
				
			case 6:{
				String msg = "#VENDENDO UM PRODUTO#";
				String nome = JOptionPane.showInputDialog(msg + "\n\nNOME DO PRODUTO:").toUpperCase();
				
				int pos = estoq.pegaPosicao(nome);
				if (pos<0){
					JOptionPane.showMessageDialog(null,"PRODUTO N�O CADASTRADO!");
					
				}else{
				
				int quantidade = Integer.parseInt(JOptionPane.showInputDialog(msg + "\n\nQUANTIDADE A SER VENDIDA:"));
				estoq.diminuirQuantidade(nome, quantidade);
				}
				break;
			}
			
			case 7:{
				String msg = "#COMPRANDO UM PRODUTO#";
				String nome = JOptionPane.showInputDialog(msg + "\n\nNOME DO PRODUTO:").toUpperCase();
				
				int pos = estoq.pegaPosicao(nome);
				if (pos<0){
					JOptionPane.showMessageDialog(null,"PRIMEIRAMENTE CADASTRE ESTE PRODUTO!");
					
				}else{
				
					int quantidade = Integer.parseInt(JOptionPane.showInputDialog(msg + "\n\nQUANTIDADE A SER COMPRADA:"));
					estoq.aumentarQuantidade(nome, quantidade);
				}
				break;
			}
			
			case 8:{
				String msg = "#VERIFICANDO QUANTIDADE NO ESTOQUE#";
				String nome = JOptionPane.showInputDialog(msg + "\n\nNOME DO PRODUTO:").toUpperCase();		
				int quantidade = Integer.parseInt(JOptionPane.showInputDialog(msg + "\n\nQUANTIDADE DESEJADA NO PEDIDO:"));
				estoq.verificarQuantidade(nome, quantidade);
				break;
			}
			
			case (9):{
				estoq.mostrarAbaixoMinimo();
				break;
			}
			
			case 10:{
				estoq.mostrarTodos();
			}
			
			}
		}
		while(op!=0);    
		
		JOptionPane.showMessageDialog(null, "OBRIGADO POR UTILIZAR NOSSO SISTEMA!"
				+"\n\nPROGRAMADORES:  F�bio Dela Bruna"
				+"\n                                      " + "M�rcio Oz�rio");
	}
	
	
	
	/**
	 * Le um produto e cadastra no estoque
	 */
	private static void inserirProduto() {
		TProduto produto = new TProduto();
		String msg = "#CADASTRANDO UM NOVO PRODUTO#";
		
		String nome = JOptionPane.showInputDialog(msg + "\n\nPRODUTO:").toUpperCase();
		produto.setNome(nome);
		
		int pos = estoq.pegaPosicao(nome);
			if (pos>=0){
				JOptionPane.showMessageDialog(null,"PRODUTO JA CADASTRADO!");
		
			}else{
		
				int codigo = Integer.parseInt(JOptionPane.showInputDialog(msg + "\n\nC�DIGO:"));
				produto.setCodigo(codigo);
				
				double preco = Double.parseDouble(JOptionPane.showInputDialog(msg + "\n\nPRE�O:"));
				produto.setPreco(preco);
				
				double qtdEstoque = Double.parseDouble(JOptionPane.showInputDialog(msg + "\n\nQUANTIDADE:"));
				produto.setQtdEstoque(qtdEstoque);
		
				double qtdMinima = Double.parseDouble(JOptionPane.showInputDialog(msg + "\n\nQUANT. M�NIMA PARA ESTOQUE:"));
				produto.setQtdMinima(qtdMinima);
		
				estoq.inserirProduto(produto);
				
				JOptionPane.showMessageDialog(null, "PRODUTO CADASTRADO COM SUCESSO!");
			}
			
	}
	
	
}