import javax.swing.JOptionPane;



public class TEstoque {
	
	private TProduto produto[] = new TProduto[100];
	TProduto prod = new TProduto();
	private int qtdProd = 0;

	
	
	public TEstoque(TProduto[] produto, int qtdProd) {
		this.produto = produto;
		this.qtdProd = qtdProd;
	}
	
	
	
	public TEstoque() {

	}

	
	
	/**
	 * Cadastra um produto 
	 */
	public void inserirProduto(TProduto produto){
		this.produto[qtdProd] = produto;
		qtdProd++;
	}
	
	
	
	/**
	 * Remove um produto
	 */
	public void removerProduto(String nome){
		int pos = pegaPosicao(nome);
		if (pos<0){
			JOptionPane.showMessageDialog(null,"PRODUTO N�O CADASTRADO!");
		}else{
			for (int i=pos; i<qtdProd; i++){
				produto[i] = produto[i+1];
			}
			qtdProd--;
			JOptionPane.showMessageDialog(null,"PRODUTO EXCLU�DO COM SUCESSO!");
		}
	}
	
	
	
	/**
	 * Utilizado para pegar a posi��o do produto a ser exclu�do
	 */
	public int pegaPosicao(String nome){
		for (int i = 0; i < qtdProd; i++){
			if (nome.equalsIgnoreCase(produto[i].getNome())){
				return i;
			}
		}
		return -1;
	}
	
	
	
	/**
	 * Faz a busca de um produto
	 */
	public void consultarProduto(String nome){
		if(qtdProd>0){
			for (int i=0; i<qtdProd; i++){
				if (nome.equalsIgnoreCase(produto[i].getNome())){
					JOptionPane.showMessageDialog(null, produto[i].toString());
				}
			}
		}else{
			JOptionPane.showMessageDialog(null, "CADASTRAR UM PRODUTO PRIMEIRAMENTE");
		}
	}

	
		
	/**
	 * Aumenta o pre�o de um produto espec�fico
	 */
	public void aumentarPrecoEspecifico(String nome, double porcentagem){

		for (int i=0;i<qtdProd;i++){
			if (nome.equalsIgnoreCase(produto[i].getNome())){
				produto[i].aumentaPreco(porcentagem);
				JOptionPane.showMessageDialog(null, produto[i].toString());
			}else{
				JOptionPane.showMessageDialog(null, "PRODUTO N�O CADASTRADO");
			}
		}
	}
	
	
	
	/**
	 * Aumenta o pre�o de todos os produtos
	 */
	public void aumentoPrecoGeral(double porcentagem){
		for (int i=0;i<qtdProd;i++){
			this.produto[i].aumentaPreco(porcentagem);
		}
	}

	
	
	/**
	 * Diminui a quantidade de um produto eno estoque
	 */
	public void diminuirQuantidade(String nome, int quantidade){
		for (int i=0; i<qtdProd; i++){
				if(this.produto[i].getQtdEstoque()>=quantidade){
					if (nome.equalsIgnoreCase(this.produto[i].getNome())){
						produto[i].decrementaQuantidade(quantidade);
						JOptionPane.showMessageDialog(null, "VENDA EFETUADA COM SUCESSO!");
					}else{
						JOptionPane.showMessageDialog(null, "ESTOQUE INSUFICIENTE!!");
					}
				}
		}
	}
	
	
	
	/**
	 * Aumenta a quantidade de um produto no estoque
	 */
	public void aumentarQuantidade(String nome, int quantidade){
		for (int i=0; i<qtdProd; i++){
			if (nome.equalsIgnoreCase(this.produto[i].getNome())){
				produto[i].incrementaQuantidade(quantidade);
				JOptionPane.showMessageDialog(null, "COMPRA EFETUADA COM SUCESSO!");
			}
		}
	}
	
	
	
	/**
	 * Verifica a quantidade de um produto no estoque
	 */
	public void verificarQuantidade(String nome, int quantidade){
		for (int i=0; i<qtdProd; i++){
			if(this.produto[i].getNome().equalsIgnoreCase(nome)){
				if(this.produto[i].getQtdEstoque()<=quantidade){
					JOptionPane.showMessageDialog(null, "ESTOQUE INSUFICIENTE!");
				}else{
					JOptionPane.showMessageDialog(null, "ESTOQUE EST� NORMAL!");
				}
			}
		}
	}
	
	
	
	/**
	 * Mostra os produtos que est�o abaixo da quantidade minima no estoque
	 */
	public void mostrarAbaixoMinimo(){
		for (int i=0; i<qtdProd; i++){
			if(this.produto[i].getQtdEstoque()<this.produto[i].getQtdMinima()){
				JOptionPane.showMessageDialog(null, "#PRODUTOS ABAIXO DA QTD. M�NIMA#\n\n"+produto[i].toString());								
			}else{
				JOptionPane.showMessageDialog(null, "NENHUM PRODUTO EST� ABAIXO DA QTD. M�NIMA!");
			}
		}
	}
	
	
	
	/**
	 * Mostra todos os produtos cadastrados
	 */
	public void mostrarTodos(){
		if(qtdProd>0){
			for (int i = 0; i < qtdProd; i++){
				JOptionPane.showMessageDialog(null, produto[i]);
			}
		}else{
			JOptionPane.showMessageDialog(null, "NENHUM PRODUTO CADASTRADO!.");
		}
	}
	
	
	
	/**
	 * Getters e Setters
	 */
	public TProduto[] getProduto() {
		return produto;
	}

	public void setProduto(TProduto[] produto) {
		this.produto = produto;
	}

	public int getQtdProd() {
		return qtdProd;
	}

	public void setQtdProd(int qtdProd) {
		this.qtdProd = qtdProd;
	}

	
		
	
}