
public class TProduto {
    private String nome;
    private int codigo;
    private double preco, qtdEstoque, qtdMinima;
    

    /**
     * Construtor sem par�metro
     */
    public TProduto(){
    	
    	this("", 0.0, 0, 0.0, 0.0);
    	
    }
    
    
    
    /**
     * Construtor com par�metro
     */
    public TProduto(String nome, double preco, int codigo, double qtdEstoque, double qtdMinima) {
		this.nome = nome;
		this.preco = preco;
		this.codigo = codigo;
		this.qtdEstoque = qtdEstoque;
		this.qtdMinima = qtdMinima;
	}



    /**
     * M�todo toString
     */
	public String toString(){
        return "PRODUTO: " + this.nome
        	+ "\nC�DIGO: " + this.codigo
            + "\nPRE�O: R$ " + this.preco 
            + "\nQUANTIDADE M�NIMA: " + this.qtdMinima
            + "\nQUANTIDADE NO ESTOQUE:" + this.qtdEstoque;

	}
	
	
	
	/**
	 * Aumenta o pre�o do produto
	 */
	void aumentaPreco(double porcentagem) {
		preco += preco*(porcentagem/100);
	}

	
	
	/**
	 * Diminui o pre�o do produto
	 */
	void diminuiPreco(double porcentagem) {
		preco -= preco*(porcentagem/100);
	}

	
	
	/**
	 * Incrementa
	 */
	public void incrementaQuantidade(){
		qtdEstoque++;
	}

	
	
	/**
	 * Decrementa
	 */
	public void decrementaQuantidade(){
		qtdEstoque--;
	}

	
	
	/**
	 * Incrementa a quantidade
	 * @param quantidade
	 */
	public void incrementaQuantidade(int quantidade){
		this.qtdEstoque = this.qtdEstoque+quantidade;
	}

	
	
	/**
	 * Decrementa a quantidade
	 * @param quantidade
	 */
	public void decrementaQuantidade(int quantidade){
		this.qtdEstoque = this.qtdEstoque-quantidade;
	}
	
	
	
	/**
	 * Getters e Setters
	 */
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	public void setQtdEstoque(double qtdEstoque) {
		this.qtdEstoque = qtdEstoque;
	}
	
	
	public void setQtdMinima(double qtdMinima) {
		this.qtdMinima = qtdMinima;
	}


	public int getCodigo() {
		return codigo;
	}


	public String getNome() {
		return nome;
	}

	
	public double getPreco() {
		return preco;
	}
	

	public double getQtdEstoque() {
		return qtdEstoque;
	}
    
	
	public double getQtdMinima() {
		return qtdMinima;
	}
   
    
}
