import javax.swing.JOptionPane;


public class metodo_insercao {

	static int[] ord;
	public static void main(String[] args) {
	int n = Integer.parseInt(JOptionPane.showInputDialog("Quantos numeros deseja digitar?"));
	ord = new int[n];
		ler(n);
		ordenar(ord,n);
		

	}
	

static void ler(int n){
	for(int i=0;i<n;i++){
		ord[i]=Integer.parseInt(JOptionPane.showInputDialog("Entre com um numero"));
		
	}
}
static void ordenar (int[] num,int n) {
    int aux;
    for (int i=0; i < n; i++){
        for (int m=1; m < (n-i); m++){
        	if (num[m-1]>num[m]){
                	aux = num[m];
                	num[m] = num[m-1];
                	num[m-1]=aux;
            }
        }
    }
    mostrar(num,n);
}
static void mostrar(int[] v,int n){
	String res="";
	for(int i=0;i<n;i++){
		res +=String.valueOf(v[i])+"\n";
	}
	JOptionPane.showMessageDialog(null,res );

}
}