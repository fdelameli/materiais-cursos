import java.awt.JobAttributes;

import javax.swing.JOptionPane;

public class ordem {
	    private static int v[] = new int[1000];
	    private static int tamanhoV;
	    private static int i,j;
	    private static int comparacao = 0;
	    
	    public static void main(String args[]){
	    	
	    	//ler tamanho do vetor
	    	tamanhoV = Integer.parseInt(JOptionPane.showInputDialog(null, "<html><head></head><body><font size='10'>Digite a quantidade de n�meros do seu vetor<br><br></body></html>", "Ordenador Bolha", JOptionPane.PLAIN_MESSAGE));
	    	
	    	//ler valores
	    	for(int h = 0; h < tamanhoV; h++){
	    		v[h] = Integer.parseInt(JOptionPane.showInputDialog(null, "<html><head></head><body><font size='10'>Digite o n�mero "+(h+1)+"<br><br></body></html>", "Ordenador Bolha", JOptionPane.PLAIN_MESSAGE));
	    	}
	    	
	    	// Algoritmo Bolha
	    	// *******************************************************************
	    	// *******************************************************************
	    	for(i = 0; i < tamanhoV-1; i++){
	            for(j = 0; j < tamanhoV-1;j++){
	            	mostraVetor();
	            	comparacao ++;
	            	if(v[j] > v[j+1]){
	                    int aux = v[j];  v[j] = v[j+1]; v[j+1]=aux;
	                }
	            }
	        }
	        // *******************************************************************
	        // *******************************************************************
	        
	    	// mostrar resultado final
	        String msg = "";
	    	for(int h = 0; h < tamanhoV; h++){
	    		msg += v[h]+"<br>";
	    	}
	        JOptionPane.showMessageDialog(null, "<html><head></head><body><font size='10'>E o resultado final �:<br><br><p align='center'>"+msg+
	        		"</p><br>N�mero de compara��es realizadas: "+comparacao+
	        		"<br><br></body></html>", "Ordenador Bolha", JOptionPane.PLAIN_MESSAGE);
	    }
	    
	    // m�todo utilizado para mostrar o vetor a cada passo
	    public static void mostraVetor(){
	    	String msg = "";
	    	for(int h = 0; h < tamanhoV; h++){
	    		if(h == j || h == (j+1)){
	    			msg += v[h]+" *<br>";
	    		} else{
	    			msg += v[h]+" -<br>";
	    		}
	    	}
	    	JOptionPane.showMessageDialog(null,"<html><head></head><body><font size='10'>Compara��o atual = "
	    			+(comparacao+1)+"<br>Vari�vel i = "
	    			+i+"<br>Vari�vel j = "+j+"<br><br><p align = 'center'>"+msg+"<br></font></p>" +
	    					"</body></html>","Ordenador Bolha" , JOptionPane.PLAIN_MESSAGE);
	    }
}
