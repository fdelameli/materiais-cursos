import javax.swing.JOptionPane;

	public class selection{
		
		public static void main(String[] args) {
			
		int tam= Integer.parseInt(JOptionPane.showInputDialog("Digite o Tamanho do Vetor:"));
		int vetor[] = new int[tam];
		
		Ler(vetor, tam);
	
		Ordenar(vetor);
		
		Mostrar(vetor, tam);
	}
	
	static void Ler(int[] vetor, int tam){
		for (int i= 0;i< tam; i++){
			vetor[i]= Integer.parseInt(JOptionPane.showInputDialog("Digite um Numero Inteiro:"));
		}
	}
		
	static void Ordenar(int[] vetor) {
		int pos;
		int aux;
		for (int i=0; i< vetor.length; i++) {
			pos= i;
			for (int j=i; j< vetor.length; j++) {
				if (vetor[pos]> vetor[j]) {
					pos= j;
				}             
			}
			aux = vetor[pos];
			vetor[pos] = vetor[i];
			vetor[i] = aux;
		}
	}
	
	static void Mostrar(int[] vetor, int tam){
		String resul= "|| N�MEROS ORDENADOS ||\n\n";
		for (int i = 0; i< tam - 1; i++) {
			resul+= vetor[i]+" - ";
		}
		resul+= vetor[tam-1];
		
		JOptionPane.showMessageDialog(null, resul);
	}
	
}
