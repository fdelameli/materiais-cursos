public class FullQueueException extends RuntimeException {
    
    public FullQueueException(String reason) {
        super(reason);
    }
}