//a biblioteca dll deve estar na pasta system32
class Fiscal
{
   private native void ReducaoZ(String s);
   private native void LeituraX(String s);
   public static void main (String args[]) 
   {
      Fiscal fiscal=new Fiscal();
      fiscal.ReducaoZ("I");
      fiscal.LeituraX("F");
   }
 
   static 
   {
      System.loadLibrary("Urano32.dll");
   }
}

