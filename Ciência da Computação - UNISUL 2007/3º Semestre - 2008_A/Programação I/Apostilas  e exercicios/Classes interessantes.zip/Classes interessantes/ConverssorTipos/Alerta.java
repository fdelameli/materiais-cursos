import java.awt.*;
import java.awt.Frame;
import java.awt.Dimension;
import java.awt.SystemColor;
import javax.swing.JLabel;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.Color;
import java.awt.Label;
import java.awt.Button;

public class Alerta extends Frame 
{

	private static Label label1 = new Label();
	private static Label label = new Label();
	private static String Mensagem = "";
	private Button button1 = new Button();
	
	public Alerta(String valor)
	{
	try
	{
	  jbInit(valor);
	}
	catch(Exception e)
	{
	  e.printStackTrace();
	}
	
	}
	
	private void jbInit(String valor) throws Exception
	{
		this.setLayout(null);
		this.setSize(new Dimension(419, 120));
		this.setTitle("Aviso!");
		this.setBackground(SystemColor.control);
		label1.setText("!");
		label1.setBounds(new Rectangle(20, 20, 45, 55));
		label1.setFont(new Font("Arial", 1, 55));
		label1.setForeground(Color.red);
		label.setText(valor);
		label.setBounds(new Rectangle(65, 30, 325, 30));
		label.setFont(new Font("Dialog", 0, 15));
		button1.setLabel("OK");
		button1.setBounds(new Rectangle(165, 65, 71, 27));
		this.add(button1, null);
		this.add(label, null);
		this.add(label1, null);
		this.setLocation(200,70);
		
		this.setVisible(true);
		
	}
	
	public boolean action(Event evt, Object arg)
	{
	  	if(evt.target instanceof Button)
	  	{
	  		String label = (String)arg;
	  		if(label.equals("OK"))
	  		{
	  			hide();
	  			return(true);
	  		}
	  		return(false);
	  	}
	  	return(false);
	}
  
	public void Mostrar(String Message)
	{
		Mensagem = Message;
		label.setText(Mensagem);
		setVisible(true);
		show();
	}  
}