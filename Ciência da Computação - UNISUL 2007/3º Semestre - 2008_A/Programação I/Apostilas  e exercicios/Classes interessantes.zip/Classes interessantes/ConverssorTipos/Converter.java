import java.applet.Applet;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Label;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.Choice;
import java.awt.Panel;
import java.awt.Color;
import java.awt.TextField;
import java.awt.Button;
import java.awt.TextArea;
import java.awt.ScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Converter extends Applet 
{
  private Label label1 = new Label();
  private Label label2 = new Label();
  private Choice De = new Choice();
  private Choice Para = new Choice();
  private Panel panel1 = new Panel();
  private TextField tf = new TextField();
  private Button Calcular = new Button();
  private Button Limpar = new Button();
  private TextArea ta = new TextArea();
  private DecBin db = new DecBin();
  
  public Converter()
  {
  }

  public void init()
  {
    try
    {
      jbInit();
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

  }

  private void jbInit() throws Exception
  {
    this.setLayout(null);
    this.setSize(new Dimension(400, 316));
    label1.setText("De:");
    label1.setBounds(new Rectangle(15, 10, 28, 16));
    label1.setFont(new Font("Dialog", 0, 14));
    label1.setBackground(new Color(168, 165, 158));
    label2.setText("Para:");
    label2.setBounds(new Rectangle(200, 10, 40, 15));
    label2.setFont(new Font("Dialog", 0, 14));
    label2.setBackground(new Color(168, 165, 158));
    De.setBounds(new Rectangle(40, 10, 135, 20));
    Para.setBounds(new Rectangle(240, 10, 135, 20));
    panel1.setBounds(new Rectangle(5, 5, 390, 30));
    panel1.setBackground(new Color(168, 165, 158));
    tf.setBounds(new Rectangle(5, 40, 390, 20));
    Calcular.setLabel("Calcular");
    Calcular.setBounds(new Rectangle(105, 70, 85, 20));
    Calcular.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          Calcular_actionPerformed(e);
        }
      });
    Limpar.setLabel("Limpar");
    Limpar.setBounds(new Rectangle(195, 70, 80, 20));
    Limpar.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent e)
        {
          Limpar_actionPerformed(e);
        }
      });
    ta.setForeground(new Color(53, 74, 185));
    ta.setBounds(new Rectangle(5, 100, 390, 180));
        
    De.add("Bin�rio");
    De.add("Decimal");    
    De.add("Octal");
    De.add("Hexadecimal");
    Para.add("Bin�rio");
    Para.add("Decimal");    
    Para.add("Octal");
    Para.add("Hexadecimal");
    
    this.add(Limpar, null);
    this.add(Calcular, null);
    this.add(tf, null);
    this.add(Para, null);
    this.add(De, null);
    this.add(label2, null);
    this.add(label1, null);
    this.add(panel1, null);
    this.add(ta, null);
  }

  private void Calcular_actionPerformed(ActionEvent e)
  {
  	   String Resultado = db.Convercao(De.getSelectedIndex(),Para.getSelectedIndex(),
	   tf.getText().toUpperCase());
	   
	   if(!Resultado.equals(""))
	   {
	   	  ta.append(Resultado);
	      ta.append("\n-----------------------------------------------------------------------------\n");	  			
	   }
  }

  private void Limpar_actionPerformed(ActionEvent e)
  {
     ta.setText("");
     tf.setText("");
  }
}