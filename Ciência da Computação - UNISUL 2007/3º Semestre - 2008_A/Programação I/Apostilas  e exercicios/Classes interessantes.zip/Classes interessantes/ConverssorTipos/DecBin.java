import java.math.BigInteger;
import java.math.BigDecimal;

public class DecBin
{
	static Alerta alerta = null;
	
	static int RetornaNumeroVirgula(String Valor)	
	{
		int i,cont=0;
		for(i=0; i < Valor.length(); i++)
		{
			if((Valor.charAt(i) == ',')||(Valor.charAt(i) == '.'))
			{	
				cont++;
			}
		}
		
		return cont;		
	}
	
	static int RetornaPosicaoVirgula(String Valor)
	{
		for(int i=0; i < Valor.length(); i++)
		{
			if((Valor.charAt(i) == ',')||(Valor.charAt(i) == '.'))
			{	
				return i;
			}
		}
		return 0;
	}
		
	static BigInteger ParteInteira(String Valor, int Posicao)
	{	
		return( new BigInteger(Valor.substring(0,Posicao)) );
	}
		
	static BigDecimal ParteDecimal(String Valor, int PosicaoInicial)
	{		
		return( new BigDecimal("0." + Valor.substring(PosicaoInicial + 1, Valor.length()) ) );
	}
	
	static int RetornaTamanho(String Valor)
	{
		return ( Valor.length() );
	}
	
	static String CalculoParteInteiraDecimal(BigInteger Inteiro)	
	{		
		return( Inteiro.toString(2) );
	}
	
	static String CalculoParteFracionariaDecimal(BigDecimal Fracao)
	{			
		int cont=0;
		String Retorna="";		
		BigDecimal zero = new BigDecimal("0");
		BigDecimal dois = new BigDecimal("2");
				
		while(Fracao.compareTo(zero) != 0 && cont<1000)
		{			
				
			Fracao = Fracao.multiply( dois );
			
			Retorna += ParteInteira(Fracao.toString(),RetornaPosicaoVirgula(Fracao.toString()));
		
			Fracao = ParteDecimal(Fracao.toString(),RetornaPosicaoVirgula(Fracao.toString())); 
						
			cont++;
		}		
		
		return Retorna;
	}
	
	static String CalculoParteInteiraBinaria(String Inteiro, int posicao)
	{	
		BigInteger bi = new BigInteger(Inteiro.substring(0,posicao),2);
		return(bi.toString());
	}
	
	static String CalculoParteFracionariaBinaria(String Fracao)
	{			
		
		BigDecimal d = new BigDecimal("1");
		BigDecimal r = new BigDecimal("0");
											
		for(int i = 0; i < Fracao.length(); i++){
			for(int j = 1; j <= i+1; j++){
				d = d.multiply(new BigDecimal("0.5"));								
			}		

			BigDecimal iz = new BigDecimal("" + Fracao.charAt(i));
			BigDecimal t = new BigDecimal(d.multiply(iz).toString());
			r = r.add( t );
				
			d = new BigDecimal("1");			
		}	
		
		return( r.toString().substring(2,r.toString().length()) );
	}		
	
	static String ConverterRestanteDecimal(String lido, int tipo, int novo)
	{
		BigInteger converter = new BigInteger(lido,tipo);
		return(converter.toString(novo));
	}
	
	static String RetornaResultadoDecimal(String lido)
	{
		String Uniao = "";
		if(RetornaNumeroVirgula(lido) == 1)
		{
			Uniao = CalculoParteInteiraDecimal(ParteInteira(
				lido,RetornaPosicaoVirgula( lido ))) +			
			 "."							
			+ CalculoParteFracionariaDecimal(
					ParteDecimal(lido,RetornaPosicaoVirgula(
						lido)));		
		}
		
		else if(RetornaNumeroVirgula(lido) == 0)
		{			
			Uniao = CalculoParteInteiraDecimal(ParteInteira(lido,RetornaTamanho(lido)));
		}
		
		return Uniao;
	}	
	
	static String RetornaResultadoBinario(String lido)
	{
		String Uniao = "";
		if(RetornaNumeroVirgula(lido) == 1)
		{
			Uniao = CalculoParteInteiraBinaria(lido, RetornaPosicaoVirgula( lido ))
			+			
			 "."	
			+						
			CalculoParteFracionariaBinaria(lido.substring(RetornaPosicaoVirgula(lido)+1,lido.length()));
		}		
		else if(RetornaNumeroVirgula(lido) == 0)
		{			
			Uniao = CalculoParteInteiraBinaria(lido, RetornaTamanho(lido));
		}
		
		return Uniao;
	}
	
	static boolean Consistencia(String lido, String vetor)
	{		
		boolean status = false;
		
		for(int i = 0; i < lido.length(); i++)
		{
			for(int j = 0; j < vetor.length(); j++)
			{				
				if(lido.charAt(i) == vetor.charAt(j))
				{
					status = true;
					break;
				}	
			}
			if(status == false)
				return false;
			else
				status = false;				
		}
		return true;
	}	
		
	static String Convercao(int de, int para, String lido)
	{						
		if(lido.length()>0)
		{	
			switch(de)
			{
				case 0:
					de = 2;
					break;
				case 1:
					de = 10;
					break;
				case 2:
					de = 8;
					break;
				case 3:
					de = 16;
					break;
			}
			
			switch(para)
			{
				case 0:
					para = 2;
					break;
				case 1:
					para = 10;
					break;
				case 2:
					para = 8;
					break;
				case 3:
					para = 16;
					break;
			}		
			
			if(de==2&&para==10)
			{
				if(Consistencia(lido,"01.,")==true)
					return( RetornaResultadoBinario(lido) );
				else
				{
					alerta = new Alerta("Dados em formato inv�lido!");
					//return("Dados em formato inv�lido!");
					return("");
				}
			}
			
			if(de==10&&para==2)
			{
				if(Consistencia(lido,"0123456789.,")==true)
					return( RetornaResultadoDecimal(lido) );
				else
				{
					alerta = new Alerta("Dados em formato inv�lido!");
					//return("Dados em formato inv�lido!");
					return("");
				}
			}
			
			if(de == para)
			{
				alerta = new Alerta("Calculo desnecess�rio(Tipos iguais)" );
				//return("Calculo desnecess�rio(Tipos iguais)" );
				return("");
			}
						
			if(de==16)
			{
				if(Consistencia(lido,"0123456789ABCDEF")==true)
					return( ConverterRestanteDecimal(lido, de, para) );	
				else
				{
					alerta = new Alerta("Dados em formato inv�lido!");
					//return("Dados em formato inv�lido!");
					return("");
				}
			}
			else
			{
				if(Consistencia(lido,"0123456789")==true)
					return(ConverterRestanteDecimal(lido, de, para) );
				else
				{
					alerta = new Alerta("Dados em formato inv�lido!");
					//return("Dados em formato inv�lido!");
				}
			}						
		}
		else
		{
			alerta = new Alerta("� necess�rio que seja inserido algum valor!");
			return("");
			//return("� necess�rio que seja inserido algum valor!");
		}
		return("");			
	}		
}