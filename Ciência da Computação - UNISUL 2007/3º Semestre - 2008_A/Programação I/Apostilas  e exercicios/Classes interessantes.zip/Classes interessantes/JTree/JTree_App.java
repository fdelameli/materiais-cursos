
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;

//*****************************************************************************
//*****************************************************************************
//*****************************************************************************

class Aluno {
	private String Nome, Endereco;
	private int Idade;
	private JCheckBox JCB;
	
	public Aluno(String Nome_a, String Endereco_a, int Idade_a, boolean bb) {
		
		Nome=Nome_a;
		Endereco=Endereco_a;
		Idade=Idade_a;
		
		JCB = new JCheckBox(Nome);
		JCB.setSelected(bb);
		
	};
	
	public void setSelected(boolean bb) {
		
		JCB.setSelected(bb);
		
	};
	
	public boolean isSelected() {
		
		return(JCB.isSelected());
		
	};
	
	public String toString() {
		
		String Str=Nome;
		
		return(Str);
	};
	
	public String Print_All() {
		
		String Str=Nome+", "+Idade+", "+Endereco+", "+JCB.isSelected();
		
		return(Str);
	};
	
};

//*****************************************************************************
//*****************************************************************************
//*****************************************************************************

class CheckBoxNodeRenderer implements TreeCellRenderer {
	
	private JCheckBox JCB = new JCheckBox();
	private DefaultTreeCellRenderer nonLeafRenderer = new DefaultTreeCellRenderer();
	
	private Color selectionBorderColor, selectionForeground, selectionBackground,
	              textForeground, textBackground;
    
	public CheckBoxNodeRenderer() {
		
	};
	
	protected JCheckBox getJCheckBox() {
		
		return(JCB);
	};
	
	public Component getTreeCellRendererComponent(JTree tree, Object value,
	                                              boolean selected, boolean expanded, boolean leaf, int row,
	                                              boolean hasFocus) {
		
		Component returnValue;
		if (leaf) {
			
			String stringValue = tree.convertValueToText(value, selected, expanded, leaf, row, false);
			JCB.setText(stringValue);
			JCB.setSelected(false);
			
			JCB.setEnabled(tree.isEnabled());
			
			if (selected) {
				JCB.setForeground(selectionForeground);
				JCB.setBackground(selectionBackground);
			} else {
				JCB.setForeground(textForeground);
				JCB.setBackground(textBackground);
			}
			
			if ((value != null) && (value instanceof DefaultMutableTreeNode)) {
				Object userObject = ((DefaultMutableTreeNode) value).getUserObject();
				if (userObject instanceof Aluno) {
					Aluno Aln = (Aluno) userObject;
					JCB.setText(Aln.toString());
					JCB.setSelected(Aln.isSelected());
					//JCB.setSelected(false);
				}
			}
			returnValue = JCB;
		} else {
			returnValue = nonLeafRenderer.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);
		}
		return returnValue;
	}
	
};

//*****************************************************************************
//*****************************************************************************
//*****************************************************************************

class JTree_Frame extends JFrame {
	private FlowLayout FLV0,FLH1;
	private JPanel Pn_FLH1;
	private Container Cnt;
	
	private JScrollPane JSP0,JSP1;
	private JTextArea TA1;
	private JButton Get_Bt1;
	
	private CheckBoxNodeRenderer CBNR;
	private Aluno Aln[];
	
	private DefaultMutableTreeNode Root, Node1, Node2,
	                               SubNode1[], SubNode2[];
	private JTree Tree;
	
	
	public JTree_Frame(int dx, int dy) {
		
		init();
    	init_event();
    	
    	setLocation(180,10);
    	setSize(dx,dy);
		setResizable(false);
    	
    	show();
	}
	
	public void init_event() {
        
        this.addWindowListener(
  	       new WindowAdapter() {
  	   	      public void windowClosing(WindowEvent WE1) {
  			     hide();
  	   	    	 System.exit(0);
  			     
  		      }
  		   }
  	    );
  	    
        Get_Bt1.addActionListener(
      	   new ActionListener() {
      		  public void actionPerformed(ActionEvent AE1) {
      			  
      			  Pega_Toda_Arvore();
					
      		  }	
      	   }
        );
        
        Tree.addMouseListener(
			new MouseListener() {
				public void mouseClicked(MouseEvent ME1) {
					
					Pega_Node();
					
				}
				public void mouseReleased(MouseEvent ME1) {
					
				}
				public void mousePressed(MouseEvent ME1) {
					
				}
				public void mouseExited(MouseEvent ME1) {
					
				}
				public void mouseEntered(MouseEvent ME1) {
					
				}
			}
		);
	    
    }
    
    public void Pega_Node() {
    	
    	DefaultMutableTreeNode node=(DefaultMutableTreeNode)Tree.getLastSelectedPathComponent();
		if (node!=null) {
		   if (node==Root)
		      TA1.setText("Root Clicked.\n");
		   else {
		      if (node.isLeaf()) {
		         Aluno Aln=(Aluno)node.getUserObject();
		         if (Aln.isSelected())
		            Aln.setSelected(false);
		         else
		            Aln.setSelected(true);
		         repaint(); //para atualizar a tela
		         TA1.setText("Aluno="+Aln.Print_All()+" Clicked.\n");
		      } else
		         TA1.setText("Node="+node.toString()+" Clicked.\n");
		   };
		} else
		   TA1.setText("Node=null Clicked.\n");
    };
    
    public void Pega_Toda_Arvore() {
    	
    	if (Root!=null) {
      	   TA1.setText("Arvore:\n");
      	   TA1.append("    "+Root.toString()+"\n");
      	   int n=Root.getChildCount();
      	   for (int i=0;i<n;i++) {
      	      TA1.append("        "+Root.getChildAt(i).toString()+"\n");
      		  int m=Root.getChildAt(i).getChildCount();
      		  for (int j=0;j<m;j++) {
      		  	 DefaultMutableTreeNode node=(DefaultMutableTreeNode)Root.getChildAt(i).getChildAt(j);
      		  	 if (node.isLeaf()) {
      		  	 	Aluno Aln=(Aluno)node.getUserObject();
      		  	 	TA1.append("            "+Aln.Print_All().toString()+"\n");
      		  	 } else {
      		  	 	TA1.append("            "+node.toString()+"\n");
      		  	 };
      		  };
      	   };
		} else
		   TA1.setText("Arvore vazia.\n");
    };
    
    public void init_tree() {
		
		Aln=new Aluno[8];
		for (int i=0;i<Aln.length;i++)
		   Aln[i]=new Aluno("Nome "+i, "Av. Rio Branco", 20, false);
		
		SubNode1=new DefaultMutableTreeNode[4];
		for (int i=0;i<SubNode1.length;i++)
		   SubNode1[i]=new DefaultMutableTreeNode(Aln[i]);
		
		SubNode2=new DefaultMutableTreeNode[4];
		for (int i=0;i<SubNode1.length;i++)
		   SubNode2[i]=new DefaultMutableTreeNode(Aln[i+4]);
		
		Node1 = new DefaultMutableTreeNode("Node1");
		Node2 = new DefaultMutableTreeNode("Node2");
		
		for (int i=0;i<SubNode1.length;i++)
		   Node1.add(SubNode1[i]);
		
		for (int i=0;i<SubNode2.length;i++)
		   Node2.add(SubNode2[i]);
		
		Root = new DefaultMutableTreeNode("Root");
		
		Root.add(Node1);
		Root.add(Node2);
		
		Tree = new JTree(Root);
		
		CBNR = new CheckBoxNodeRenderer();
        Tree.setCellRenderer(CBNR);
        
        Tree.setEditable(true);
		Tree.setEnabled(true);
		
        JSP0=new JScrollPane(Tree,
	                         JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
	                         JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	    JSP0.setPreferredSize(new Dimension(160,380));
		
	};
	
	
    public void init() {
		
		Cnt=this.getContentPane();
		Cnt.setBackground(Color.orange);
		
		FLV0=new FlowLayout();
		FLV0.setHgap(620);
		FLV0.setVgap(10);
		Cnt.setLayout(FLV0);
		
		FLH1=new FlowLayout();
		FLH1.setHgap(10);
		FLH1.setVgap(0);
		
		Pn_FLH1=new JPanel();
		Pn_FLH1.setBackground(Color.orange);
		Pn_FLH1.setLayout(FLH1);
		
		Get_Bt1=new JButton("Get all");
		Get_Bt1.setEnabled(true);
		
		init_tree();
		
		
		TA1=new JTextArea("");
		TA1.setText("");
		
		JSP1=new JScrollPane(TA1,
		                     JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
		                     JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		JSP1.setPreferredSize(new Dimension(480,380));
		
		Cnt.add(Pn_FLH1);
		Cnt.add(Get_Bt1);
		
		Pn_FLH1.add(JSP0);
		Pn_FLH1.add(JSP1);
		
	}
}

//*****************************************************************************
//*****************************************************************************
//*****************************************************************************

public class JTree_App {
	
	public static void main(String Args[]) {
		
		JTree_Frame JTF=new JTree_Frame(680,540);
		
	}
}
