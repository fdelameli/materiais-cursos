/*****************************************************************************
 *
 *              Microchip DeviceNet Stack (Application Template)
 *
 *****************************************************************************
 * FileName:        template.c
 * Dependencies:    
 * Processor:       PIC18F with CAN
 * Compiler:       	C18 02.10.02 or higher
 * Linker:          MPLINK 03.20.01 or higher
 * Company:         Microchip Technology Incorporated
 *
 * Software License Agreement
 *
 * The software supplied herewith by Microchip Technology Incorporated
 * (the "Company") is intended and supplied to you, the Company's
 * customer, for use solely and exclusively with products manufactured
 * by the Company. 
 *
 * The software is owned by the Company and/or its supplier, and is 
 * protected under applicable copyright laws. All rights are reserved. 
 * Any use in violation of the foregoing restrictions may subject the 
 * user to criminal sanctions under applicable laws, as well as to 
 * civil liability for the breach of the terms and conditions of this 
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES, 
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A 
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT, 
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR 
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *
 *
 * Author               Date        Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ross Fosler			07/02/03	...	
 * 
 *****************************************************************************/

#include	"dnet.def"			// Global definitions
#include 	"typedefs.h"		// Global type definitions

#include	"services.h"		// Current list of known service codes
#include	"errors.h"			// Current list of known error codes
#include	"class.h"			// Current list of known class codes

#include	"route.h"			// Public functions, variables, and more from the router object



/*********************************************************************
 * Function:        unsigned char AssemblyExplMsgHandler(void)
 *
 * PreCondition:    
 *
 * Input:       
 *                  
 * Output:         	
 *
 * Side Effects:    
 *
 * Overview:        Handler for explicit messaging, static model.
 *
 * Note:            None
 ********************************************************************/
unsigned char AppClassXX(void)
{
	// Decode the instance
	switch (mRouteGetInstanceID())
	{
		// Class level (instance 0) 
		case 0:
			// Decode services for this instance
			switch(mRouteGetServiceID())
			{
				case _GET_ATTRIB_SINGLE:
					// Develope your code here
					break;
								
				default:
					mRoutePutError(_SERVICE_NOT_SUPPORTED);
					break;
			}
			break;
			
		// Instance 1
		case 1:
			// Decode services for this instance
			switch(mRouteGetServiceID())
			{
				// Refer to services.h for a list of common services
				// or a custom service can be provided
			
			
				case _GET_ATTRIB_SINGLE:
					// Develope your code here
					break;

				case _SET_ATTRIB_SINGLE:
					// Develope your code here
					break;	
				
				default:
					mRoutePutError(_SERVICE_NOT_SUPPORTED);
					break;
			}
			break;										
		
		
		// Add other static instances if necessary
		
		
		// All other instances 
		default:	
			mRoutePutError(_OBJECT_DOES_NOT_EXIST);
			break;
	}

	return (1);
}

			 

