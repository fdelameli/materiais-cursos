
// General 
#define USE_ACCESS				1

 
#define B125k_BRG1_SJW			2
#define B125k_BRG1_PRESCALE		3 
#define B125k_BRG2_SEG2PHTS		1
#define B125k_BRG3_WAKFIL 		1 
#define B125k_BRG2_SEG1PH 		2
#define B125k_BRG3_SEG2PH 		2
#define B125k_BRG2_PRSEG 		2
#define B125k_BRG2_SAM 			0

#define B250k_BRG1_SJW			2
#define B250k_BRG1_PRESCALE		1 
#define B250k_BRG2_SEG2PHTS		1
#define B250k_BRG3_WAKFIL 		1 
#define B250k_BRG2_SEG1PH 		2 
#define B250k_BRG3_SEG2PH 		2
#define B250k_BRG2_PRSEG 		2
#define B250k_BRG2_SAM 			0

#define B500k_BRG1_SJW			2
#define B500k_BRG1_PRESCALE		0 
#define B500k_BRG2_SEG2PHTS		1
#define B500k_BRG3_WAKFIL 		1 
#define B500k_BRG2_SEG1PH 		2 
#define B500k_BRG3_SEG2PH 		2
#define B500k_BRG2_PRSEG 		2
#define B500k_BRG2_SAM 			0

//#define	B125k_BRGCON0			0x83
//#define	B125k_BRGCON1			0x92
//#define	B125k_BRGCON2			0xC2

//#define	B250k_BRGCON0			0x81
//#define	B250k_BRGCON1			0x92
//#define	B250k_BRGCON2			0xC2

//#define	B500k_BRGCON0			0x80
//#define	B500k_BRGCON1			0x92
//#define	B500k_BRGCON2			0xC2


#define CLASS_WIDTH_16BIT		0
#define INSTANCE_WIDTH_16BIT	0


#define TICK_RESOLUTION			8		// 1, 2, 4, 8, 16, 32, 64

#define	EXPLICIT_ACK_TIMER		2048L


// Messaging
#define SUPPORT_EXPLICIT		1
#define	SUPPORT_POLLED			1
#define	SUPPORT_BIT_STROBED		1
#define	SUPPORT_MULTICAST_POLL	1
#define	SUPPORT_COS				1
#define	SUPPORT_CYCLIC			1
#define SUPPORT_COS_BOTH_DIR	1


// Build in fragmentation support
#define	FRAGMENTATION_UNACK		1
#define	FRAGMENTATION_ACK		1

// Explicit messaging buffer size
#define	CONN_EXPLICIT_RX_SIZE	40
#define	CONN_EXPLICIT_TX_SIZE	40

// Fragmentation support for IO connections
#define	CONN_POLLED_RX_FRAG		1
#define	CONN_POLLED_TX_FRAG		1
#define	CONN_MULTICAST_RX_FRAG	1
#define	CONN_MULTICAST_TX_FRAG	1
#define CONN_COS_CYCLIC_RX_FRAG	1
#define CONN_COS_CYCLIC_TX_FRAG	1


// DeviceNet Object Parameters
#define	ALLOW_MAC_ID			1
#define	ALLOW_BAUD_RATE			1
#define	ALLOW_BOI				1
#define	ALLOW_BUS_OFF_COUNT		1
#define	ALLOW_ATTRIB_ALLOC_INFO	1
#define	ALLOW_MAC_ID_SW_CH		1
#define	ALLOW_BAUD_RATE_SW_CH	1
#define	ALLOW_MAC_ID_SW_VAL		1
#define	ALLOW_BAUD_RATE_SW_VAL	1
#define	SETTABLE_BUS_OFF_COUNT	1
#define	SETTABLE_BOI			1
#define	SETTABLE_BAUD_RATE		1
#define	SETTABLE_MAC_ID			1


#define	CLASS_USER_DEFINED_1			64
#define	CLASS_USER_DEFINED_1_NAME		AppClass1

#define	CLASS_USER_DEFINED_2 			0
#define	CLASS_USER_DEFINED_2_NAME		MyClass2

#define	CLASS_USER_DEFINED_3			0
#define	CLASS_USER_DEFINED_3_NAME		MyClass3

#define	CLASS_USER_DEFINED_4			0
#define	CLASS_USER_DEFINED_4_NAME		MyClass4

#define	CLASS_USER_DEFINED_5			0
#define	CLASS_USER_DEFINED_5_NAME		MyClass5

#define	CLASS_USER_DEFINED_6			0
#define	CLASS_USER_DEFINED_6_NAME		MyClass6

#define	CLASS_USER_DEFINED_7			0
#define	CLASS_USER_DEFINED_7_NAME		MyClass7

#define	CLASS_USER_DEFINED_8			0
#define	CLASS_USER_DEFINED_8_NAME		MyClass8
