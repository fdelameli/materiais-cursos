/******************************************************************
 *****                                                        *****
 *****  Name: webside.c                                       *****
 *****  Ver.: 1.0                                             *****
 *****  Date: November 2001                                   *****
 *****  Auth: Andreas Dannenberg                              *****
 *****  Func: example HTML-code for easyweb.c                 *****
 *****                                                        *****
 ******************************************************************/


#include "..\IE_API\Diretivas.h"
const char pszInicio[]={""};
/*

const char pszInicio[] = {"HTTP/1.0 200 OK\r\n"                   //Prot ver 1.0,code 200, reason OK.
"Server: MSP430/1.0.00 (Embedded)\r\n"  //Servidor que est� enviando a p�g.
"Content-Type: text/html\r\n"           //Tipo de dados que vamos enviar.
"\r\n"                                  //Indica o fim do cabe�alho HTTP.
"<html>\r\n"                            //Inicio da p�gina Web.
"<head>\r\n"
"<meta http-equiv=\"refresh\" content=\"30\">\r\n"
"<title>Internet Embedded - Website dinamico</title>\r\n"
"</head>\r\n"
"\r\n<br>"
};
*/

