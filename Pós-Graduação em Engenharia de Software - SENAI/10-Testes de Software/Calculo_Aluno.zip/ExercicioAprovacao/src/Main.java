import javax.swing.JOptionPane;

import app.CalcularAprovacao;

public class Main {

	public static void main(String[] args) {

		CalcularAprovacao calc = new CalcularAprovacao();

		String resultado = "";

		float n1, n2, freq;
		int codAluno;
		String nota1, nota2, frequencia;
		
		codAluno = Integer.parseInt(JOptionPane.showInputDialog("Digite o c�digo do aluno: "));
		nota1 = (JOptionPane.showInputDialog("Digite a primeira nota: "));
		n1 = Float.parseFloat(nota1);
		nota2 = (JOptionPane.showInputDialog("Digite a segunda nota: "));
		n2 = Float.parseFloat(nota2);
		frequencia = (JOptionPane.showInputDialog("Digite a frequencia: "));
		freq = Float.parseFloat(frequencia);
		
		resultado = calc.CalcularAprovacao(codAluno, calc.CalcularFrequencia(freq),
				calc.calcularMedia(n1, n2));
		
			
		System.out.println(resultado);

		JOptionPane.showMessageDialog(null, resultado);

	}

}
