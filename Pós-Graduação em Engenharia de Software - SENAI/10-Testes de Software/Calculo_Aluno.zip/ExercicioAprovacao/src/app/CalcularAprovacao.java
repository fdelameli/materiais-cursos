package app;

import java.util.ArrayList;

public class CalcularAprovacao {

	public boolean CalcularFrequencia(float freq) {

		boolean resultadoFreq = false;

		if (freq >= 75 || freq == 0) {

			resultadoFreq = true;
		}

		return resultadoFreq;
	}

	public boolean calcularMedia(float nota1, float nota2) {

		boolean resultadoMedia = false;

		float nota = (nota1 + nota2) / 2;

		if (nota == 0) {

			return resultadoMedia;

		} else if (nota >= 7.0) {

			resultadoMedia = true;
		}

		return resultadoMedia;
	}

	public String CalcularAprovacao(int id, boolean freq, boolean media) {

		
		String nomeAluno = buscarAluno(id);
		

		String resultado = "";
		if (freq && media) {

			resultado = "O aluno(a) " + nomeAluno + " foi APROVADO";
		} else {

			resultado = "O aluno(a) " + nomeAluno + " foi REPROVADO";
		}

		return resultado;
	}

	public String buscarAluno(int id) {

		ArrayList<String> alunos = new ArrayList<>();
		alunos.add("Fabiano");
		alunos.add("Taize");
		alunos.add("Helder");
		alunos.add("Ramon");
		alunos.add("GG");
		alunos.add("Mauricio");

		return alunos.get(id);

	}



}
