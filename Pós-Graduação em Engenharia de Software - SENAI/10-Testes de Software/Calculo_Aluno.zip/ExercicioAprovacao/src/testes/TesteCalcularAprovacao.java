package testes;

import static org.mockito.Mockito.*;
import org.junit.Assert;
import org.junit.Test;


import app.CalcularAprovacao;

public class TesteCalcularAprovacao {

	CalcularAprovacao calcula = new CalcularAprovacao();

	@Test
	public void testeFrequenciaPassou() {
		boolean result = calcula.CalcularFrequencia(76);
		System.out.println(result);
		Assert.assertTrue(result);

	}

	@Test
	public void testeFrequenciaPassouApertado() {
		boolean result = calcula.CalcularFrequencia(75);
		System.out.println(result);
		Assert.assertTrue(result);

	}

	@Test
	public void testeFrequenciaReprovou() {
		boolean result = calcula.CalcularFrequencia(74);
		System.out.println(result);
		Assert.assertFalse(result);

	}

	@Test
	public void testeMediaAprovouApertado() {
		boolean result = calcula.calcularMedia(7, 7);
		System.out.println(result);
		Assert.assertTrue(result);
	}

	@Test
	public void testeMediaAprovou() {
		boolean result = calcula.calcularMedia(8, 8);
		System.out.println(result);
		Assert.assertTrue(result);
	}

	@Test
	public void testeMediaReprovou() {
		boolean result = calcula.calcularMedia(0, 0);
		System.out.println(result);
		Assert.assertFalse(result);
	}

	@Test
	public void testeAprovacao() {
		CalcularAprovacao calculaSpy = spy(calcula);		
		when(calculaSpy.buscarAluno(0)).thenReturn("Fabiano");
		String result = calculaSpy.CalcularAprovacao(0, true, true);
		Assert.assertEquals(result, "O aluno(a) " + "Fabiano" + " foi APROVADO");
	}

	@Test
	public void testeReprovacaoFrequncia() {
		String result = calcula.CalcularAprovacao(0, false, true);
		Assert.assertEquals(result, "O aluno(a) " + "Fabiano"
				+ " foi REPROVADO");

	}

	@Test
	public void testeReprovacaoMedia() {
		String result = calcula.CalcularAprovacao(0, true, false);
		Assert.assertEquals(result, "O aluno(a) " + "Fabiano"
				+ " foi REPROVADO");

	}

	@Test
	public void testeReprovacaoOvelhaNegra() {
		String result = calcula.CalcularAprovacao(0, false, false);
		Assert.assertEquals(result, "O aluno(a) " + "Fabiano"
				+ " foi REPROVADO");

	}

	// public int mockAluno() {
	//
	// int mockAluno = "";
	// return mockAluno;
	// }
	//

}
